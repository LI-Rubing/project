<?php include("include/header.php"); ?>

<body>
  <?php include("sections/sidenav.html"); ?>

  <div class="container-fluid">
    <div class="container">
      <?php
      require "php/header.php";
      createHeader('shopping-bag', 'Manage Medicines Stock', 'Manage Existing Medicine Stock');
      ?>

      <div class="row">
        <!-- Barre de recherche -->
        <div class="col-md-12 form-group form-inline">
          <label class="font-weight-bold" for="">Search :&emsp;</label>
          <input type="text" class="form-control" id="by_name" placeholder="By Medicine Name"
            onkeyup="searchMedicineStock(this.value, 'nom');">
          &emsp;<input type="text" class="form-control" id="by_generic_name" placeholder="By Active Ingredient"
            onkeyup="searchMedicineStock(this.value, 'principe_actif');">
          &emsp;<button class="btn btn-primary font-weight-bold" onclick="filterByTherapeuticFamily();">Filter by
            Therapeutic Family</button>
          &emsp;<button class="btn btn-success font-weight-bold" onclick="cancel();"><i
              class="fa fa-refresh"></i></button>
        </div>


        <!-- Tableau des médicaments -->
        <div class="col-md-12 table-responsive">
          <table class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th>SL.</th>
                <th>Medicine Name</th>
                <th>Form</th>
                <th>Active Ingredient</th>
                <th>Therapeutic Family</th>
                <th>Price (€)</th>
                <th>Reimbursement (%)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="medicine_list">
              <?php require "php/manage_medicine_stock.php"; ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <script src="js/manage_medicine_stock.js"></script>
</body>

</html>