<?php 
// Connexion à la base de données PostgreSQL
$servername = "postgresql-zineddine.alwaysdata.net";
$usernameDB = "zineddine";
$passwordDB = "Zinedine.2021";
$dbname = "zineddine_sgph";

try {
    $con = new PDO("pgsql:host=$servername;dbname=$dbname", $usernameDB, $passwordDB);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
