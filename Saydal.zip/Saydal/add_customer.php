<!-- including side navigations -->

<?php
include("include/header.php");
include("sections/sidenav.html"); ?>
<div class="container-fluid">
  <div class="container"> 
    <!-- header section -->
    <?php
    require "php/header.php";
    createHeader('handshake', 'Add Patient', 'Add New Patient');
    // header section end
    ?>
    <div class="row">
      <div class="row col col-md-12"> 
        <?php
        // form content
        // require "sections/add_new_customer.html";
        ?>
      <!-- </div>
    </div>
    <hr style="border-top: 2px solid #ff5252;">
  </div>
</div>
</body>

</html> -->


<?php
// Load necessary dependencies
require_once 'php/db_connection.php'; // Database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Patient</title>
    <style>
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
        }
        input[type="text"],
        input[type="date"],
        input[type="radio"],
        input[type="password"],
        input[type="submit"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .submit-btn {
            background-color: #02b6ff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #45a049;
        }
        .message {
            padding: 10px;
            margin: 10px 0;
            text-align: center;
            font-weight: bold;
            border-radius: 4px;
        }
        .success {
            color: green;
            background-color: #e8f5e9;
        }
        .error {
            color: red;
            background-color: #ffebee;
        }
        @media (max-width: 600px) {
            .container {
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Add New Patient</h1>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $firstName = $_POST['customer_name'] ?? null;
        $lastName = $_POST['customer_lastname'] ?? null;
        $dateOfBirth = $_POST['customer_dob'] ?? null;
        $address = $_POST['customer_address'] ?? null;

        $socialSecNum = $_POST['customer_num_secu'] ?? null;
        $insured = ($_POST['is_insured'] ?? 'false') === "true";
        $cardExpirationDate = $_POST['customer_expiracy_date'] ?? null;
        $socialSecRegime = $_POST['regime_secu'] ?? null;

        try {
            // Insert into Person table
            $sqlPerson = "INSERT INTO Personne (prenom, nom, date_de_naissance, adresse) 
                          VALUES (:firstName, :lastName, :dateOfBirth, :address) 
                          RETURNING id_personne";
            $stmt = $con->prepare($sqlPerson);
            $stmt->bindParam(':firstName', $firstName);
            $stmt->bindParam(':lastName', $lastName);
            $stmt->bindParam(':dateOfBirth', $dateOfBirth);
            $stmt->bindParam(':address', $address);
            $stmt->execute();

            $personId = $stmt->fetchColumn();

            // Insert into Patient table
            $sqlPatient = "INSERT INTO Patient (num_secu, assure, id_personne, date_validite_carte_vitale, regime_secu)
                           VALUES (:socialSecNum, :insured, :personId, :cardExpirationDate, :socialSecRegime)";
            $stmt = $con->prepare($sqlPatient);
            $stmt->bindParam(':socialSecNum', $socialSecNum);
            $stmt->bindParam(':insured', $insured, PDO::PARAM_BOOL);
            $stmt->bindParam(':personId', $personId);
            $stmt->bindParam(':cardExpirationDate', $cardExpirationDate);
            $stmt->bindParam(':socialSecRegime', $socialSecRegime);
            $stmt->execute();

            echo "<div class='message success'>Patient successfully added.</div>";
        } catch (PDOException $e) {
            echo "<div class='message error'>Error: " . $e->getMessage() . "</div>";
        }
    }
    ?>
    <form action="" method="POST">

    <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_name">First Name</label>
            <input type="text" id="customer_name" name="customer_name" required>
        </div>
    </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_lastname">Last Name</label>
            <input type="text" id="customer_lastname" name="customer_lastname" required>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_dob">Date of Birth</label>
            <input type="date" id="customer_dob" name="customer_dob" required>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_address">Address</label>
            <textarea id="customer_address" name="customer_address" required></textarea>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_num_secu">Social Security Number</label>
            <input type="text" id="customer_num_secu" name="customer_num_secu" required>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="customer_expiracy_date">Health Card Expiration Date</label>
            <input type="date" id="customer_expiracy_date" name="customer_expiracy_date" required>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label>Insurance</label><br>
            <input type="radio" id="insured_yes" name="is_insured" value="true">
            <label for="insured_yes">Yes</label><br>
            <input type="radio" id="insured_no" name="is_insured" value="false" checked>
            <label for="insured_no">No</label>
        </div>
        </div>

        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <label for="regime_secu">Social Security Regime</label>
            <input type="text" id="regime_secu" name="regime_secu" required>
        </div>
        </div>
      <div class="col col-md-12">
      <hr class="col-md-12 float-left" style="padding: 0px; width: 95%; border-top: 2px solid  #02b6ff;">
    </div>
        <div class="row col col-md-12">
        <div class="col col-md-12 form-group">
            <input type="submit" value="Add Patient" class="submit-btn">
        </div>
        </div>

    </form>

</div>
</div>
        <hr style="border-top: 2px solid #ff5252;">
  </div>

</body>
</html>