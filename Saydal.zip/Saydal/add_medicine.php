<?php
include("include/header.php");
include("sections/sidenav.html"); ?>
<div class="container-fluid">
    <div class="container">
        <!-- header section -->
        <?php
        require "php/header.php";
        createHeader('shopping-bag', 'Add Medicine', 'Add New Medicine');
        // header section end
        ?>
        <div class="row">
            <div class="row col col-md-12">
                <?php
                // form content
                // require "sections/add_new_customer.html";
                ?>
                <!-- </div>
    </div>
    <hr style="border-top: 2px solid #ff5252;">
  </div>
</div>
</body>

</html> -->


                <?php
                // Load necessary dependencies
                require_once 'php/db_connection.php'; // Database connection
                ?>

                <!DOCTYPE html>
                <html lang="en">

                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Add New Medication</title>
                    <style>
                        h1 {
                            text-align: center;
                            margin-bottom: 20px;
                        }

                        label {
                            font-size: 14px;
                            margin-bottom: 5px;
                            display: block;
                        }

                        input[type="text"],
                        input[type="number"],
                        input[type="date"],
                        input[type="radio"],
                        input[type="submit"],
                        textarea {
                            width: 100%;
                            padding: 10px;
                            margin-bottom: 15px;
                            border-radius: 4px;
                            border: 1px solid #ddd;
                        }

                        .form-group {
                            margin-bottom: 20px;
                        }

                        .submit-btn {
                            background-color: #02b6ff;
                            color: white;
                            border: none;
                            cursor: pointer;
                        }

                        .submit-btn:hover {
                            background-color: #45a049;
                        }

                        .message {
                            padding: 10px;
                            margin: 10px 0;
                            text-align: center;
                            font-weight: bold;
                            border-radius: 4px;
                        }

                        .success {
                            color: green;
                            background-color: #e8f5e9;
                        }

                        .error {
                            color: red;
                            background-color: #ffebee;
                        }

                        @media (max-width: 600px) {
                            .container {
                                padding: 10px;
                            }
                        }
                    </style>
                </head>

                <body>

                    <div class="container">
                        <h1>Add New Medication</h1>
                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            // Retrieve form data
                            $medName = $_POST['med_name'] ?? null;
                            $description = $_POST['med_description'] ?? null;
                            $activePrinciple = $_POST['med_principle'] ?? null;
                            $price = $_POST['med_price'] ?? null;
                            $reimbursable = ($_POST['med_reimbursable'] ?? 'false') === "true";
                            $therapeuticFamily = $_POST['med_family'] ?? null;
                            $form = $_POST['med_form'] ?? null;
                            $cipCode = $_POST['med_cip_code'] ?? null;
                            $reimbursementRate = $_POST['med_reimbursement_rate'] ?? null;
                            $quantity = $_POST['med_quantity'] ?? 0;
                            $alertThreshold = $_POST['med_alert_threshold'] ?? 0;
                            $expiryDate = $_POST['med_expiry_date'] ?? null;

                            try {
                                // Check if the medication exists
                                $checkMedication = "SELECT id_medicaments FROM medicament WHERE nom = :medName";
                                $stmtCheck = $con->prepare($checkMedication);
                                $stmtCheck->bindParam(':medName', $medName);
                                $stmtCheck->execute();
                                $medicament = $stmtCheck->fetch(PDO::FETCH_ASSOC);

                                if ($medicament) {
                                    // Récupérer l'ID du médicament
                                    $idMedicaments = $medicament['id_medicaments'];

                                    // Insérer dans la table stock (si ce n'est pas déjà fait)
                                    $insertStock = "INSERT INTO stock (id_stock)
                                    VALUES (:idMedicaments)
                                    ON CONFLICT (id_stock) DO NOTHING"; // On ne fait rien si l'ID de stock existe déjà
                                    $stmtInsertStock = $con->prepare($insertStock);
                                    $stmtInsertStock->bindParam(':idMedicaments', $idMedicaments); // Associer les ID médicaments
                        
                                    $stmtInsertStock->execute();
                                    // Ensuite, mettre à jour la table stock_medicament
                                    $updateStock = "INSERT INTO stock_medicament (id_stock, id_medicaments, quantite, seuil_alerte, date_peremption)
                                    VALUES (:idStock, :idMedicaments, :quantity, :alertThreshold, :expiryDate)
                                    ON CONFLICT (id_stock, id_medicaments) 
                                    DO UPDATE SET quantite = stock_medicament.quantite + EXCLUDED.quantite";

                                    $stmtUpdateStock = $con->prepare($updateStock);
                                    $stmtUpdateStock->bindParam(':idStock', $idMedicaments); // id_stock doit être un ID valide
                                    $stmtUpdateStock->bindParam(':idMedicaments', $idMedicaments);
                                    $stmtUpdateStock->bindParam(':quantity', $quantity);
                                    $stmtUpdateStock->bindParam(':alertThreshold', $alertThreshold);
                                    $stmtUpdateStock->bindParam(':expiryDate', $expiryDate);
                                    $stmtUpdateStock->execute();

                                    echo "<div class='message success'>Stock updated successfully.</div>";
                                } else {
                                    // Récupérer l'ID du médicament
                                    $idMedicaments = $medicament['id_medicaments'];

                                    // Insérer dans la table stock (si ce n'est pas déjà fait)
                                    $insertStock = "INSERT INTO stock (id_stock)
                                                                        VALUES (:idMedicaments)
                                                                        ON CONFLICT (id_stock) DO NOTHING"; // On ne fait rien si l'ID de stock existe déjà
                                    $stmtInsertStock = $con->prepare($insertStock);
                                    $stmtInsertStock->bindParam(':idMedicaments', $idMedicaments); // Associer les ID médicaments
                        
                                    $stmtInsertStock->execute();
                                    // Add new medication and stock
                                    $sqlMedicament = "INSERT INTO medicament (nom, descrip, principe_actif, prix, remboursable, famille_therapeutique, forme, code_cip, taux_remboursement)
                    VALUES (:medName, :description, :activePrinciple, :price, :reimbursable, :therapeuticFamily, :form, :cipCode, :reimbursementRate)";
                                    $stmt = $con->prepare($sqlMedicament);
                                    $stmt->bindParam(':medName', $medName);
                                    $stmt->bindParam(':description', $description);
                                    $stmt->bindParam(':activePrinciple', $activePrinciple);
                                    $stmt->bindParam(':price', $price);
                                    $stmt->bindParam(':reimbursable', $reimbursable, PDO::PARAM_BOOL);
                                    $stmt->bindParam(':therapeuticFamily', $therapeuticFamily);
                                    $stmt->bindParam(':form', $form);
                                    $stmt->bindParam(':cipCode', $cipCode);
                                    $stmt->bindParam(':reimbursementRate', $reimbursementRate);
                                    $stmt->execute();
                                    $idMedicaments = $con->lastInsertId();

                                    // Insert stock with id_medicaments as id_stock
                                    $insertStock = "INSERT INTO stock_medicament (id_stock, id_medicaments, quantite, seuil_alerte, date_peremption)
                    VALUES (:idMedicaments, :idMedicaments, :quantity, :alertThreshold, :expiryDate)";
                                    $stmtInsertStock = $con->prepare($insertStock);
                                    $stmtInsertStock->bindParam(':idMedicaments', $idMedicaments); // id_stock and id_medicaments are the same
                                    $stmtInsertStock->bindParam(':quantity', $quantity);
                                    $stmtInsertStock->bindParam(':alertThreshold', $alertThreshold);
                                    $stmtInsertStock->bindParam(':expiryDate', $expiryDate);
                                    $stmtInsertStock->execute();

                                    echo "<div class='message success'>Medication added and stock updated successfully.</div>";
                                }
                            } catch (PDOException $e) {
                                echo "<div class='message error'>Error: " . $e->getMessage() . "</div>";
                            }
                        }
                        ?>
                        <form action="" method="POST">

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_name">Medication Name</label>
                                    <input type="text" id="med_name" name="med_name" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_description">Description</label>
                                    <textarea id="med_description" name="med_description" required></textarea>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_principle">Active Principle</label>
                                    <input type="text" id="med_principle" name="med_principle" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_price">Price</label>
                                    <input type="number" id="med_price" name="med_price" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label>Reimbursable</label><br>
                                    <input type="radio" id="reimbursable_yes" name="med_reimbursable" value="true">
                                    <label for="reimbursable_yes">Yes</label><br>
                                    <input type="radio" id="reimbursable_no" name="med_reimbursable" value="false"
                                        checked>
                                    <label for="reimbursable_no">No</label>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_family">Therapeutic Family</label>
                                    <input type="text" id="med_family" name="med_family" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_form">Form</label>
                                    <input type="text" id="med_form" name="med_form" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_cip_code">CIP Code</label>
                                    <input type="text" id="med_cip_code" name="med_cip_code" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_reimbursement_rate">Reimbursement Rate (%)</label>
                                    <input type="number" id="med_reimbursement_rate" name="med_reimbursement_rate"
                                        required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_quantity">Quantity</label>
                                    <input type="number" id="med_quantity" name="med_quantity" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_alert_threshold">Alert Threshold</label>
                                    <input type="number" id="med_alert_threshold" name="med_alert_threshold" required>
                                </div>
                            </div>

                            <div class="row col col-md-12">
                                <div class="col col-md-12 form-group">
                                    <label for="med_expiry_date">Expiry Date</label>
                                    <input type="date" id="med_expiry_date" name="med_expiry_date" required>
                                </div>
                            </div>

                            <div class="form-group text-center">
                                <input type="submit" class="submit-btn" value="Add Medication">
                            </div>

                        </form>
                    </div>
            </div>

            </body>

            </html>