<?php
include("include/header.php");
include("sections/sidenav.html");
require_once 'php/db_connection.php'; // Connexion à la base de données
?>

<div class="container-fluid">
  <div class="container">
    <!-- header section -->
    <?php
    require "php/header.php";
    createHeader('home', 'Dashboard', 'Home');
    ?>

    <!-- Section des alertes (médicaments en stock bas ou périmés) -->

    <div class="row">
      <?php
      // Récupérer les médicaments dont le stock est <= 10 ou dont la date de péremption est dépassée
      $sqlAlert = "SELECT s.id_medicaments, m.nom, s.quantite, s.date_peremption
             FROM stock_medicament s
             JOIN medicament m ON s.id_medicaments = m.id_medicaments
             WHERE s.quantite <= 10 OR s.date_peremption < CURRENT_DATE";

      $stmt = $con->prepare($sqlAlert);
      $stmt->execute();
      $alerts = $stmt->fetchAll(PDO::FETCH_ASSOC);

      // Afficher les alertes si elles existent
      if ($alerts) {
          foreach ($alerts as $alert) {
              echo '
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4" style="padding: 10px;">
                  <div class="alert alert-warning" role="alert">
                    <strong>Alert:</strong> ' . htmlspecialchars($alert['nom']) . ' - Stock: ' . $alert['quantite'] . ' - Expiration: ' . $alert['date_peremption'] . '
                  </div>
                </div>
              ';
          }
          echo '<hr style="border-top: 2px solid #ff5252;">';  // Ligne rouge après les alertes
      }
      ?>
    </div>

    <!-- Section des autres éléments du dashboard (Add New...) -->
    <hr style="border-top: 2px solid #ff5252;"> <!-- Ligne rouge avant les sections "Add New..." -->

    <div class="row">
      <?php
      // Créer les sections "Add New..." du dashboard
      function createSection2($icon, $location, $title)
      {
          echo '
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3" style="padding: 10px;">
              <div class="dashboard-stats" style="padding: 30px 15px;" onclick="location.href=\'' . $location . '\'">
                <div class="text-center">
                  <span class="h1"><i class="fa fa-' . $icon . ' p-2"></i></span>
                  <div class="h5">' . $title . '</div>
                </div>
              </div>
            </div>
          ';
      }

      createSection2('handshake', 'add_customer.php', 'Add New Customer');
      createSection2('shopping-bag', 'add_medicine.php', 'Add New Medicine');
      ?>

    </div>

    <hr style="border-top: 2px solid #ff5252;"> <!-- Ligne rouge après les sections "Add New..." -->

  </div>
</div>

</body>
</html>
