<?php
require "db_connection.php";

if ($con) {
    $action = $_GET['action'] ?? null;

    switch ($action) {
        case "filter_by_family":
            filterByTherapeuticFamily();
            break;
        case "delete":
            $id = $_GET['id'] ?? null;
            if ($id) deleteStockEntry($id);
            break;

        case "edit":
            $id = $_GET['id'] ?? null;
            if ($id) showMedicinesStock($id);
            break;

        case "update":
            $id = $_GET['id'] ?? null;
            $prix = $_GET['prix'] ?? null;
            $taux_remboursement = $_GET['taux_remboursement'] ?? null;
            if ($id && $prix && $taux_remboursement) {
                updateStockEntry($id, $prix, $taux_remboursement);
            }
            break;

        case "search":
            $text = strtoupper($_GET['text'] ?? '');
            $column = $_GET['tag'] ?? '';
           // searchMedicineStock($text, $column);
            break;

        default:
            showMedicinesStock();
            break;
    }
}

// Fonction pour afficher les médicaments
function showMedicinesStock($id = null)
{
    global $con;
    $query = "SELECT id_medicaments, nom, descrip, principe_actif, prix, remboursable, famille_therapeutique, forme, code_cip, taux_remboursement
              FROM medicament";

    if ($id) {
        $query .= " WHERE id_medicaments = :id";
    }

    $stmt = $con->prepare($query);

    if ($id) {
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    }

    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($result as $row) {
        if ($id && $row['id_medicaments'] == $id) {
            showEditOptionsRow($row);
        } else {
            showStockRow($row);
        }
    }
}

// Affiche une ligne de stock en mode lecture
function showStockRow($row)
{
    echo "
    <tr>
        <td>{$row['id_medicaments']}</td>
        <td>{$row['nom']}</td>
        <td>{$row['forme']}</td>
        <td>{$row['principe_actif']}</td>
        <td>{$row['famille_therapeutique']}</td>
        <td>{$row['prix']} €</td>
        <td>{$row['taux_remboursement']}%</td>
        <td>
            <button class='btn btn-info btn-sm' onclick=\"editMedicineStock({$row['id_medicaments']});\">
                <i class='fa fa-pencil'></i>
            </button>
            <button class='btn btn-danger btn-sm' onclick=\"deleteMedicineStock({$row['id_medicaments']});\">
                <i class='fa fa-trash'></i>
            </button>
        </td>
    </tr>";
}

// Affiche une ligne de stock en mode édition
function showEditOptionsRow($row)
{
    echo "
    <tr>
        <td>{$row['id_medicaments']}</td>
        <td>{$row['nom']}</td>
        <td>{$row['forme']}</td>
        <td>{$row['principe_actif']}</td>
        <td>{$row['famille_therapeutique']}</td>
        <td><input type='number' class='form-control' value='{$row['prix']}' id='prix'></td>
        <td><input type='number' class='form-control' value='{$row['taux_remboursement']}' id='taux_remboursement'></td>
        <td>
            <button class='btn btn-success btn-sm' onclick=\"updateMedicineStock({$row['id_medicaments']});\">
                <i class='fa fa-check'></i>
            </button>
            <button class='btn btn-secondary btn-sm' onclick='cancel();'>
                <i class='fa fa-close'></i>
            </button>
        </td>
    </tr>";
}

// Mise à jour d'une entrée de stock
function updateStockEntry($id, $prix, $taux_remboursement)
{
    global $con;
    $query = "UPDATE medicament SET prix = ?, taux_remboursement = ? WHERE id_medicaments = ?";
    $stmt = $con->prepare($query);
    $stmt->bindParam(1, $prix, PDO::PARAM_STR);
    $stmt->bindParam(2, $taux_remboursement, PDO::PARAM_INT);
    $stmt->bindParam(3, $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        showMedicinesStock();
    } else {
        echo "Erreur lors de la mise à jour : " . $stmt->errorInfo()[2];
    }
}

// Suppression d'une entrée de stock
// Suppression d'une entrée de stock
function deleteStockEntry($id)
{
    global $con;

    try {
        // Suppression de l'entrée dans la table `medicament`
        $query = "DELETE FROM medicament WHERE id_medicaments = ?";
        $stmt = $con->prepare($query);
        $stmt->bindParam(1, $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "Médicament supprimé avec succès.";
            showMedicinesStock();
        } else {
            echo "Erreur lors de la suppression : " . implode(", ", $stmt->errorInfo());
        }
    } catch (PDOException $e) {
        echo "Erreur lors de la suppression : " . $e->getMessage();
    }
}


function filterByTherapeuticFamily()
{
    global $con;
    try {
        $query = "
            SELECT famille_therapeutique, COUNT(*) AS total, 
                   STRING_AGG(nom, ', ') AS noms_medicaments
            FROM medicament
            GROUP BY famille_therapeutique
            ORDER BY famille_therapeutique";
        $stmt = $con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Vider le tableau actuel
        echo "<tbody id='medicine_list'>";

        // Compteur global
        $rowNumber = 1;

        foreach ($result as $row) {
            // Afficher le nom de la famille thérapeutique
            echo "<tr><td colspan='8' class='font-weight-bold'>{$row['famille_therapeutique']}</td></tr>";

            // Afficher les médicaments dans cette famille
            $medicaments = explode(", ", $row['noms_medicaments']); // Séparer les médicaments par virgule
            foreach ($medicaments as $medicament) {
                echo "<tr>";
                echo "<td>{$rowNumber}</td>";  // Utiliser le compteur global
                echo "<td>{$medicament}</td>";
                echo "<td colspan='6'></td>";  // Espaces vides pour aligner les autres colonnes
                echo "</tr>";

                // Incrémenter le compteur pour chaque médicament
                $rowNumber++;
            }
        }

        echo "</tbody>";
    } catch (PDOException $e) {
        echo "<tr><td colspan='8'>Error: {$e->getMessage()}</td></tr>";
    }
}




// Recherche d'un médicament

?>
