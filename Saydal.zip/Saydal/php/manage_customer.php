<?php 
require "db_connection.php";

if ($con) {
    $action = $_GET['action'] ?? null;

    switch ($action) {
        case "delete":
            $num_secu = $_GET['num_secu'] ?? null;
            if ($num_secu) deletePatient($num_secu);
            break;

        case "edit":
            $num_secu = $_GET['num_secu'] ?? null;

            if ($num_secu) {
                $query = "SELECT p.num_secu, pr.prenom, pr.nom, pr.date_de_naissance, pr.adresse, p.date_validite_carte_vitale 
                          FROM patient p 
                          JOIN personne pr ON p.id_personne = pr.id_personne 
                          WHERE p.num_secu = ?";
                $stmt = $con->prepare($query);
                $stmt->execute([$num_secu]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    showEditOptionsRow($row);
                } else {
                    echo "No data found for the given patient.";
                }
            } else {
                echo "Invalid Social Security Number.";
            }
            break;

        case "update":
            // Update patient information
            $num_secu = $_POST['num_secu'] ?? null;
            $prenom = $_POST['prenom'] ?? null;
            $nom = $_POST['nom'] ?? null;
            $adresse = $_POST['adresse'] ?? null;
            $expiration = $_POST['expiration'] ?? null;

            if ($num_secu && $prenom && $nom && $adresse && $expiration) {
                try {
                    // Update Personne table
                    $sql_personne = "
                        UPDATE Personne 
                        SET prenom = ?, nom = ?, adresse = ? 
                        WHERE id_personne = (
                            SELECT id_personne FROM Patient WHERE num_secu = ?
                        )
                    ";
                    $stmt_personne = $con->prepare($sql_personne);
                    $stmt_personne->execute([$prenom, $nom, $adresse, $num_secu]);

                    // Update Patient table
                    $sql_patient = "
                        UPDATE Patient 
                        SET date_validite_carte_vitale = ? 
                        WHERE num_secu = ?
                    ";
                    $stmt_patient = $con->prepare($sql_patient);
                    $stmt_patient->execute([$expiration, $num_secu]);

                } catch (PDOException $e) {
                    echo "Error updating patient: " . $e->getMessage();
                }
            } else {
                echo "Invalid input data.";
            }
            showAllPatients();
            break;

        case "search":
            // Search functionality placeholder
            break;

        default:
            showAllPatients();
            break;
    }
}

function showPatientRow($row)
{
    // Échappement des données pour prévenir les injections HTML/JS
    $prenom = htmlspecialchars($row['prenom'], ENT_QUOTES, 'UTF-8');
    $nom = htmlspecialchars($row['nom'], ENT_QUOTES, 'UTF-8');
    $dateDeNaissance = htmlspecialchars($row['date_de_naissance'], ENT_QUOTES, 'UTF-8');
    $adresse = htmlspecialchars($row['adresse'], ENT_QUOTES, 'UTF-8');
    $numSecu = htmlspecialchars($row['num_secu'], ENT_QUOTES, 'UTF-8');
    $dateValiditeCarteVitale = htmlspecialchars($row['date_validite_carte_vitale'], ENT_QUOTES, 'UTF-8');

    // Génération de la ligne de tableau
    echo "
    <tr>
        <td>{$prenom} {$nom}</td>
        <td>{$dateDeNaissance}</td>
        <td>{$adresse}</td>
        <td>{$numSecu}</td>
        <td>{$dateValiditeCarteVitale}</td>
        <td>
            <button class='btn btn-info btn-sm' onclick=\"editPatient('{$numSecu}');\">
                <i class='fa fa-pencil'></i>
            </button>
            <button class='btn btn-danger btn-sm' onclick=\"deletePatient('{$numSecu}');\">
                <i class='fa fa-trash'></i>
            </button>
        </td>
    </tr>";
}


function showAllPatients()
{
    global $con;
    $query = "SELECT p.num_secu, pr.prenom, pr.nom, pr.date_de_naissance, pr.adresse, p.date_validite_carte_vitale
              FROM patient p
              JOIN personne pr ON p.id_personne = pr.id_personne";
    $stmt = $con->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($result as $row) {
        showPatientRow($row);
    }
}

function showEditOptionsRow($row)
{
    $prenom = $row['prenom'];
    $nom = $row['nom'];

    echo "
    <tr>
        <td>{$prenom} {$nom}</td>
        <td>{$row['date_de_naissance']}</td>
        <td>{$row['adresse']}</td>
        <td>{$row['num_secu']}</td>
        <td>{$row['date_validite_carte_vitale']}</td>
        <td>
            <input type='text' class='form-control' value='{$prenom}' id='prenom_{$row['num_secu']}' name='prenom'>
            <input type='text' class='form-control' value='{$nom}' id='nom_{$row['num_secu']}' name='nom'>
            <input type='text' class='form-control' value='{$row['adresse']}' id='adresse_{$row['num_secu']}' name='adresse'>
            <input type='date' class='form-control' value='{$row['date_validite_carte_vitale']}' id='expiration_{$row['num_secu']}' name='expiration'>
        </td>
        <td>
            <button class='btn btn-success btn-sm' onclick=\"updatePatient({$row['num_secu']});\">
                <i class='fa fa-check'></i>
            </button>
            <button class='btn btn-secondary btn-sm' onclick='cancel();'>
                <i class='fa fa-close'></i>
            </button>
        </td>
    </tr>";
}

function deletePatient($num_secu)
{
    global $con;

    try {
        // Étape 1 : Récupérer l'ID de la personne associée
        $query = "SELECT id_personne FROM patient WHERE num_secu = ?";
        $stmt = $con->prepare($query);
        $stmt->execute([$num_secu]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $id_personne = $result['id_personne'];

            // Étape 2 : Supprimer le patient
            $queryDeletePatient = "DELETE FROM patient WHERE num_secu = ?";
            $stmtDeletePatient = $con->prepare($queryDeletePatient);
            $stmtDeletePatient->execute([$num_secu]);

            // Étape 3 : Supprimer la personne associée
            $queryDeletePersonne = "DELETE FROM personne WHERE id_personne = ?";
            $stmtDeletePersonne = $con->prepare($queryDeletePersonne);
            $stmtDeletePersonne->execute([$id_personne]);

            echo "Patient  deleted successfully.";
        } else {
            echo "No patient found with the given social security number.";
        }

        showAllPatients();
    } catch (PDOException $e) {
        echo "Error deleting patient: " . $e->getMessage();
    }
}

?>
