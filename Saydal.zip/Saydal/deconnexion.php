<?php
session_start(); // Toujours démarrer la session

// Supprimer toutes les variables de session
session_unset();

// Détruire la session
session_destroy();

// Supprimer le cookie de session
if (isset($_COOKIE['PHPSESSID'])) {
    setcookie("PHPSESSID", "", time() - 3600, "/");
}

// Rediriger vers la page de connexion
header('Location: index.php');
exit();
?>