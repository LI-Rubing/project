// Rechercher un médicament dans le stock
function searchMedicineStock(value, column) {
  const rows = document.querySelectorAll("#medicine_list tr");
  rows.forEach((row) => {
      const cell = row.querySelector(`td:nth-child(${column === 'nom' ? 2 : 4})`);
      if (cell && cell.textContent.toLowerCase().includes(value.toLowerCase())) {
          row.style.display = "";
      } else {
          row.style.display = "none";
      }
  });
} 

// Modifier un médicament
function editMedicineStock(id) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_medicine_stock.php?action=edit&id=${id}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("medicine_list").innerHTML = xhr.responseText;
      }
  };
  xhr.send();
}

// Mettre à jour les informations d'un médicament
function updateMedicineStock(id) {
  const prix = document.getElementById("prix").value;
  const tauxRemboursement = document.getElementById("taux_remboursement").value;

  if (!prix || !tauxRemboursement) {
      alert("Veuillez remplir tous les champs.");
      return;
  }

  const xhr = new XMLHttpRequest();
  xhr.open(
      "GET",
      `php/manage_medicine_stock.php?action=update&id=${id}&prix=${prix}&taux_remboursement=${tauxRemboursement}`,
      true
  );
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("medicine_list").innerHTML = xhr.responseText;
      }
  };
  xhr.send();
}

function filterByTherapeuticFamily() {
    // Envoyer une requête à PHP pour afficher les médicaments groupés par famille thérapeutique
    var url = "php/manage_medicine_stock.php?action=filter_by_family"; // Votre script PHP qui traite le filtrage

    // Demander à PHP de retourner les médicaments groupés par famille thérapeutique
    fetch(url)
        .then(response => response.text())
        .then(data => {
            // Insérer les données retournées dans le tableau des médicaments
            document.getElementById('medicine_list').innerHTML = data;
        });
}

// Supprimer un médicament
function deleteMedicineStock(id) {
  if (!confirm("Êtes-vous sûr de vouloir supprimer ce médicament ?")) {
      return;
  }

  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_medicine_stock.php?action=delete&id=${id}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("medicine_list").innerHTML = xhr.responseText;
      }
  };
  xhr.send();
}

// Annuler une action


function cancel() {
  document.getElementById("by_name").value = "";
  document.getElementById("by_generic_name").value = "";
  searchMedicineStock("", "nom");
  searchMedicineStock("", "principe_actif");
}
