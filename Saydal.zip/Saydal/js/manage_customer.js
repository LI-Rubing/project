
// Search for a patient
function searchPatient(value, column) {
  // Récupérer toutes les lignes du tableau
  const rows = document.querySelectorAll("#patients_list tr"); // Notez l'ID correct ici
  
  // Déterminer l'index de la colonne
  let cellIndex;
  switch (column) {
    case "Name":
      cellIndex = 1; // Index de la colonne "Name"
      break;
    case "Date of Birth":
      cellIndex = 2; // Index de la colonne "Date of Birth"
      break;
    case "Address":
      cellIndex = 3; // Index de la colonne "Address"
      break;
    case "Social Sec. Number":
      cellIndex = 4; // Index de la colonne "Social Sec. Number"
      break;
    case "Card Expiration":
      cellIndex = 5; // Index de la colonne "Card Expiration"
      break;
    default:
      cellIndex = 1; // Par défaut, on recherche par "Name"
  }

  // Parcourir les lignes pour afficher/masquer en fonction de la recherche
  rows.forEach((row) => {
    const cell = row.querySelector(`td:nth-child(${cellIndex})`); // Cibler la cellule spécifique
    if (cell && cell.textContent.toLowerCase().includes(value.toLowerCase())) {
      row.style.display = ""; // Montrer la ligne si elle correspond
    } else {
      row.style.display = "none"; // Cacher la ligne sinon
    }
  });
}
 function editPatient(numSecu) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_customer.php?action=edit&num_secu=${encodeURIComponent(numSecu)}`, true);

  xhr.onload = function () {
      if (xhr.status === 200) {
          // Assurez-vous que la réponse est valide avant de l'insérer
          const response = xhr.responseText.trim();
          if (response) {
              document.getElementById("patients_list").innerHTML = response;
          } else {
              alert("No data received from the server.");
          }
      } else {
          alert("Failed to load patient data. Please check the server.");
      }
  };

  xhr.onerror = function () {
      alert("An error occurred while trying to communicate with the server.");
  };

  xhr.send();
} 
/* function editPatient(numSecu) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_customer.php?action=edit&num_secu=${numSecu}}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      }
  };
  xhr.send();
}
 */


function updatePatient(numSecu) {
  const firstName = document.getElementById(`prenom_${numSecu}`).value.trim();
  const lastName = document.getElementById(`nom_${numSecu}`).value.trim();
  const address = document.getElementById(`adresse_${numSecu}`).value.trim();
  const expirationDate = document.getElementById(`expiration_${numSecu}`).value.trim();

  if (!firstName || !lastName || !address || !expirationDate) {
      alert("Please fill in all fields.");
      return;
  }

  const xhr = new XMLHttpRequest();
  xhr.open("POST", `php/manage_customer.php?action=update`, true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      } else {
          alert("Failed to update patient information.");
      }
  };
  xhr.send(`num_secu=${numSecu}&prenom=${encodeURIComponent(firstName)}&nom=${encodeURIComponent(lastName)}&adresse=${encodeURIComponent(address)}&expiration=${encodeURIComponent(expirationDate)}`);
}

function deletePatient(numSecu) {
  if (!confirm("Are you sure you want to delete this patient?")) return;

  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_customer.php?action=delete&num_secu=${numSecu}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      } else {
          alert("Failed to delete patient.");
      }
  };
  xhr.send();
}

function cancel() {
  location.reload(); // Reload to cancel edits
}
/* function editPatient(numSecu) {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_customer.php?action=edit&num_secu=${numSecu}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      } else {
          alert("Failed to load patient data.");
      }
  };
  xhr.send();
}

function updatePatient(numSecu) {
  const firstName = document.getElementById(`prenom_${numSecu}`).value.trim();
  const lastName = document.getElementById(`nom_${numSecu}`).value.trim();
  const address = document.getElementById(`adresse_${numSecu}`).value.trim();
  const expirationDate = document.getElementById(`expiration_${numSecu}`).value.trim();

  if (!firstName || !lastName || !address || !expirationDate) {
      alert("Please fill in all fields.");
      return;
  }

  const xhr = new XMLHttpRequest();
  xhr.open("POST", `php/manage_customer.php?action=update`, true);
  xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      } else {
          alert("Failed to update patient information.");
      }
  };
  xhr.send(`num_secu=${numSecu}&prenom=${encodeURIComponent(firstName)}&nom=${encodeURIComponent(lastName)}&adresse=${encodeURIComponent(address)}&expiration=${encodeURIComponent(expirationDate)}`);
}

function deletePatient(numSecu) {
  if (!confirm("Are you sure you want to delete this patient?")) return;

  const xhr = new XMLHttpRequest();
  xhr.open("GET", `php/manage_customer.php?action=delete&num_secu=${numSecu}`, true);
  xhr.onload = function () {
      if (xhr.status === 200) {
          document.getElementById("patients_list").innerHTML = xhr.responseText;
      } else {
          alert("Failed to delete patient.");
      }
  };
  xhr.send();
}

function cancel() {
  location.reload(); // Reload to cancel edits
} */
