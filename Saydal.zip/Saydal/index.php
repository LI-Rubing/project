<?php
session_start(); // Démarrage de la session avant tout HTML ou autre sortie

// Connexion à la base de données PostgreSQL
$servername = "postgresql-zineddine.alwaysdata.net";
$usernameDB = "zineddine";
$passwordDB = "Zinedine.2021";
$dbname = "zineddine_sgph";

try {
    $conn = new PDO("pgsql:host=$servername;dbname=$dbname", $usernameDB, $passwordDB);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Initialiser une variable pour les messages
$message = "";

// Vérifier si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Préparer la requête pour récupérer les identifiants
    $stmt = $conn->prepare("SELECT login, mdp FROM pharmacien WHERE login = :login");
    $stmt->bindParam(':login', $login);
    $stmt->execute();

    // Vérifier si l'utilisateur existe
    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        $storedPassword = $user['mdp'];

        // Comparer les mots de passe directement
        if (md5($password)==$storedPassword) {
            $_SESSION['username'] = $user['login'];
            if (isset($_POST['remember'])) {
                setcookie('username', $user['login'], time() + (30 * 24 * 60 * 60), "/");
            }
            
            // Redirection après une connexion réussie
            header("Location: home.php");
            exit(); // Toujours appeler exit après une redirection
        } else {
            $message = "<div class='message error'>Mot de passe incorrect. Veuillez réessayer.</div>";
        }
    } else {
        $message = "<div class='message error'>Aucun compte trouvé avec ce login. Veuillez réessayer.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('images/pills2.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .login-container {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-box {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .login-box img {
            width: 80px;
            border-radius: 50%;
            margin-bottom: 15px;
        }
        .login-box h3 {
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .login-btn {
            width: 100%;
            padding: 10px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .login-btn:hover {
            background-color: #e04444;
        }
        
        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-box">
        <img src="images/prof.jpg" alt="User Icon">
        <h3>Login</h3>
        <form method="POST">
            <div class="form-group">
                <input type="text" name="login" placeholder="username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="password" required>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</div>
<?php
if ($message) {
    echo $message;
}
?>
</body>
</html>